<?php

$factory->define(App\king::class, function (Faker\Generator $faker) {
    return [
        'name' => $faker->name,
        'email' => $faker->email,
        'mobile'=>$faker->number,
    ];
});

?>