<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class king extends Model
{	
   public $timestamps=false; //for remove updated and created at column 
   protected $fillable = ['name', 'email', 'mobile','api_token',]; 
}
